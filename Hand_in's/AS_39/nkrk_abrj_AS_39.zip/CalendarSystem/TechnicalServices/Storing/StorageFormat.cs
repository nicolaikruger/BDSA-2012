﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalendarSystem.TechnicalServices.Storing
{
	//implemented by different classes which each specifies a special format which the Calendar can be stored locally.
	interface StorageFormat
	{
	}
}
