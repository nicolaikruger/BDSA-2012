﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalendarSystem.TechnicalServices.Storing
{
	//This class will use the .ics format to store and retrieve a Calendar on a external source like google calendar. 
	//How this is done, will be implemented on a later stage.
	class ExternalStorage
	{
	}
}
