﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Jobs;

namespace BenchmarkSystem.Computer
{
	class Computer
	{
		private int availableCPU = 10;
		private int id;

		public Computer(int id)
		{
			this.id = id;
		}

		private void reciveJob(Job job)
		{
		
		}


	}
}
